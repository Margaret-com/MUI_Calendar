import { AdapterDayjs } from "@mui/x-date-pickers/AdapterDayjs";
import { LocalizationProvider } from "@mui/x-date-pickers/LocalizationProvider";
import { DatePicker } from "@mui/x-date-pickers/DatePicker";
import dayjs from "dayjs";
import { useState, useEffect } from "react";
import {
  Button,
  TextField,
  Box,
  Stack,
  List,
  ListItem,
  IconButton,
  ListItemText,
  RadioGroup,
  Radio,
  FormControl,
  FormControlLabel,
  FormLabel,
} from "@mui/material";
import Dialog from "@mui/material/Dialog";
import DialogActions from "@mui/material/DialogActions";
import DialogContent from "@mui/material/DialogContent";
import DialogContentText from "@mui/material/DialogContentText";
import DialogTitle from "@mui/material/DialogTitle";
import Badge from "@mui/material/Badge";
import NoteAddIcon from "@mui/icons-material/NoteAdd";
import PushPinIcon from "@mui/icons-material/PushPin";
import DeleteIcon from "@mui/icons-material/Delete";
import { useColorScheme } from "@mui/material/styles";
import SettingsSuggestOutlinedIcon from "@mui/icons-material/SettingsSuggestOutlined";
import SettingsSuggestIcon from "@mui/icons-material/SettingsSuggest";
import DarkModeSharpIcon from "@mui/icons-material/DarkModeSharp";
import DarkModeOutlinedIcon from "@mui/icons-material/DarkModeOutlined";
import LightModeOutlinedIcon from "@mui/icons-material/LightModeOutlined";
import LightModeIcon from "@mui/icons-material/LightMode";

export default function Calendar() {
  const [value, setValue] = useState(dayjs());
  const [notes, setNotes] = useState([]);
  const [noteText, setNoteText] = useState("");
  const [deleteIndex, setDeleteIndex] = useState(null);
  const [openDeleteDialog, setOpenDeleteDialog] = useState(false);
  const { mode, setMode } = useColorScheme();

  // Load notes from localStorage when the app initializes
  useEffect(() => {
    const savedNotes = localStorage.getItem("notes");
    if (savedNotes) {
      try {
        const parseNotes = JSON.parse(savedNotes);
        setNotes(parseNotes);
      } catch (error) {
        console.error("Failed to parse notes from localStorage:", error);
      }
    }
  }, []);

  // Save notes to localStorage whenever notes state changes
  useEffect(() => {
    if (notes.length > 0) {
      try {
        localStorage.setItem("notes", JSON.stringify(notes));
      } catch (error) {
        console.error("Failed to save notes to localStorage:", error);
      }
    } else {
      localStorage.clear();
    }
  }, [notes]);

  const handleAddNote = () => {
    if (!noteText.trim()) {
      alert("Please enter a note.");
      return;
    }

    const formattedDate = value.format("YYYY-MM-DD");
    const newNote = { date: formattedDate, text: noteText.trim() };

    setNotes((prev) => [...prev, newNote]);
    setNoteText("");
    alert(`Your note for ${formattedDate} was added.`);
  };

  const handleOpenDeleteDialog = (index) => {
    setDeleteIndex(index);
    setOpenDeleteDialog(true);
  };

  const handleCloseDeleteDialog = () => {
    setDeleteIndex(null);
    setOpenDeleteDialog(false);
  };

  const handleDeleteNote = () => {
    setNotes((prev) => prev.filter((_, i) => i !== deleteIndex));
    handleCloseDeleteDialog();
  };


  if (!mode) {
    return null;
  }

  return (
    <LocalizationProvider dateAdapter={AdapterDayjs}>
      <Box
        sx={{
          display: "flex",
          width: "437px",
          alignItems: "center",
          justifyContent: "center",
          bgcolor: "background.paper",
          color: "text.secondary",
          borderRadius: 1,
          p: "2px",
        }}
      >
        <FormControl>
          <FormLabel id="demo-theme-toggle">Choose Your Theme Mode</FormLabel>
          <RadioGroup
            aria-labelledby="demo-theme-toggle"
            name="theme-toggle"
            defaultMode="system"
            row
            value={mode}
            onChange={(event) => setMode(event.target.value)}
          >
            <FormControlLabel
              value="system"
              control={
                <Radio
                  icon={<SettingsSuggestOutlinedIcon />}
                  checkedIcon={<SettingsSuggestIcon />}
                  size="small"
                />
              }
              label="System"
            />
            <FormControlLabel
              value="light"
              control={
                <Radio
                  icon={<LightModeOutlinedIcon />}
                  checkedIcon={<LightModeIcon />}
                  size="small"
                />
              }
              label="Light"
            />
            <FormControlLabel
              value="dark"
              control={
                <Radio
                  icon={<DarkModeOutlinedIcon />}
                  checkedIcon={<DarkModeSharpIcon />}
                  size="small"
                />
              }
              label="Dark"
            />
          </RadioGroup>
        </FormControl>
      </Box>
      <Box sx={{ textAlign: "center", padding: "20px", width: "400px", bgcolor: "background.paper" }}>
        <h1 style={{ color: "#eb71eb" }}>Calendar</h1>
        <Stack spacing={4} sx={{ alignItems: "center" }}>
          <DatePicker
            label="Select a Date"
            orientation="portrait"
            value={value}
            onChange={(newValue) => setValue(newValue)}
            sx={{  color: "text", borderRadius: "8px", fontWeight: "bold"} 
          }
          />
          <TextField
            label="Write your note here"
            multiline
            rows={4}
            variant="outlined"
            size="medium"
            fullWidth
            value={noteText}
            onChange={(e) => setNoteText(e.target.value)}
            sx={{
              bgcolor: "background.paper",
              mb: "10px",
              width: "260px",
              height: "125px",
              boxSizing: "box",
              textWrap: "pretty",
            }}
          />
          <Button
            variant="contained"
            color="secondary"
            startIcon={<NoteAddIcon />}
            onClick={handleAddNote}
            sx={{
              width: "60%",
              typography: { fontFamily: "Roboto" },
              fontWeight: "600",
            }}
          >
            Add Note
          </Button>
        </Stack>
        <h3 style={{ color: "#eb71eb" }}>Your Notes:</h3>
        <Box
          sx={{
            width: "100%",
            maxWidth: "400",
            position: "relative",
            overflow: "auto",
            maxHeight: 300,
            "& ul": { padding: 0 },
          }}
        >
          <List>
            {notes.length === 0 ? (
            <Box sx={{color: "text.primary" }}>No notes yet. Add a note to see it here!</Box>
            ) : (
              notes.map((note, index) => (
                <ListItem
                  key={index}
                  sx={{
                    bgcolor: "background.paper",
                    color:"text.primary",
                    border: "1px solid #ccc",
                    borderRadius: "8px",
                    mb: "8px",
                    justifyContent: "space-between",
                    p: "20px",
                    alignItems: "stretch",
                    overflowY: "scroll",
                    overflowX: "wrap",
                    width: "350px",
                    maxHeight: "200px",
                  }}
                >
                  <Badge
                    badgeContent={
                      <PushPinIcon
                        sx={{
                          color: "secondary.main",
                        }}
                      />
                    }
                    overlap="circular"
                  ></Badge>
                  <ListItemText
                    primary={note.text}
                    secondary={note.date}
                    sx={{ overflow: "scroll", p: "20px" }}
                  />
                  <IconButton
                    edge="end"
                    onClick={() => handleOpenDeleteDialog(index)}
                  >
                    <DeleteIcon color="secondary" />
                  </IconButton>
                </ListItem>
              ))
            )}
          </List>
        </Box>
        <Dialog
          open={openDeleteDialog}
          onClose={handleCloseDeleteDialog}
          aria-labelledby="alert-dialog-title"
          aria-describedby="alert-dialog-description"
        >
          <DialogTitle id="alert-dialog-title">Delete Note</DialogTitle>
          <DialogContent>
            <DialogContentText id="alert-dialog-description" color="text">
              Are you sure you want to delete this note? This action cannot be
              undone.
            </DialogContentText>
          </DialogContent>
          <DialogActions>
            <Button onClick={handleCloseDeleteDialog} color="secondary">
              Cancel
            </Button>
            <Button onClick={handleDeleteNote} color="primary" autoFocus>
              Delete
            </Button>
          </DialogActions>
        </Dialog>
      </Box>
    </LocalizationProvider>
  );
}
