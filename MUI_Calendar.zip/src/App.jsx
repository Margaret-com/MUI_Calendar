import "./App.css";
import Calendar from "./components/Calendar.jsx";

export default function App() {

  return (
    <div className="App" >
      <Calendar />
    </div>
  );
};
