import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import "./index.css";
import App from "./App.jsx";
import { createTheme, ThemeProvider } from "@mui/material/styles";

const newTheme = createTheme({
  colorSchemes: {
    dark: {
      palette: {
        primary: { main: "#2b2727" },
        secondary: { main: "#756b6b" },
        background: { paper: "#423e3e" },
      },
    },

    light: {
      palette: {
        primary: { main: "#262121" },
        secondary: { main: "#e67a9f" },
        background: { paper: "rgb(248, 253, 214)" },
      },
    },
  },

  components: {
    MuiPickersDay: {
      styleOverrides: {
        today: {
          color: "#f8bbd0",
          borderRadius: "20px",
          backgroundColor: "#880e4f",
        },
      },
    },
  },
});

createRoot(document.getElementById("root")).render(
  <StrictMode>
    <ThemeProvider theme={newTheme} defaultMode="system">
      <App />
    </ThemeProvider>
  </StrictMode>
);
